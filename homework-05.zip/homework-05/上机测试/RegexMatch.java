public class RegexMatch {
    public static void main(String[] args) {
        System.out.println("Java.*: " + "Java is fun".matches("Java.*"));
        System.out.println("whole: " + "I like Java".matches("Java"));
        System.out.println("digits: " + "2026".matches("\\d+"));
        System.out.println("mixed: " + "20a6".matches("\\d+"));
        System.out.println("empty *: " + "".matches("\\d*"));
        System.out.println("empty +: " + "".matches("\\d+"));
        System.out.println("dot: " + "a.b".matches("a\\.b"));
        System.out.println("newline: " + "a\nb".matches(".*"));
    }
}
