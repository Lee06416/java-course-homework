public class RegexReplace {
    public static void main(String[] args) {
        String s = "Java Java Java";
        System.out.println("all: " + s.replaceAll("v\\w", "wi"));
        System.out.println("first: " + s.replaceFirst("v\\w", "wi"));
        System.out.println("original: " + s);
        String t = "Jaaavaa";
        System.out.println("greedy: " + t.replaceFirst("a+", "R"));
        System.out.println("reluctant: " + t.replaceFirst("a+?", "R"));
    }
}
