import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexApplications {
    public static void main(String[] args) {
        System.out.println("id: " + "2024210402108".matches("[0-9]{13}"));
        System.out.println("short id: " + "202421040210".matches("[0-9]{13}"));
        System.out.println("mixed id: " + "202421040210A".matches("[0-9]{13}"));
        String rule = "[A-Za-z][A-Za-z0-9_]{5,15}";
        System.out.println("username: " + "student_01".matches(rule));
        System.out.println("digit first: " + "1student".matches(rule));
        System.out.println("short name: " + "Lee".matches(rule));
        System.out.println("image: " + "photo.jpg".matches("(?i).+\\.(jpg|png)"));
        System.out.println("upper image: " + "photo.PNG".matches("(?i).+\\.(jpg|png)"));
        System.out.println("fake suffix: " + "photoXjpg".matches("(?i).+\\.(jpg|png)"));
        String text = "Java 95, Math 88, English 100";
        Matcher m = Pattern.compile("[0-9]+").matcher(text);
        while (m.find()) {
            System.out.println("number: " + m.group());
        }
        String s = "  Java\t  is   fun  ";
        System.out.println("spaces: " + s.trim().replaceAll("\\s+", " "));
        String[] words = "Java, Python;C++  SQL".split("[,;\\s]+");
        System.out.println("split: " + Arrays.toString(words));
        System.out.println("date: " + "2026-10-13".replaceAll(
                "([0-9]{4})-([0-9]{2})-([0-9]{2})", "$1/$2/$3"));
        System.out.println("format only: " + "2026-02-30".matches(
                "[0-9]{4}-[0-9]{2}-[0-9]{2}"));
    }
}
