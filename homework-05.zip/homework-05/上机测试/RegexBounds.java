public class RegexBounds {
    public static void main(String[] args) {
        for (int n = 1; n <= 4; n++) {
            String s = "a".repeat(n);
            System.out.println(s + " / a{2,3}: " + s.matches("a{2,3}"));
        }
        String book = "[A-Z][a-zA-Z]{1,24}";
        String fixed = "[A-Z][a-zA-Z]{0,24}";
        System.out.println("A / book: " + "A".matches(book));
        System.out.println("A / fixed: " + "A".matches(fixed));
        System.out.println("Smith / fixed: " + "Smith".matches(fixed));
        System.out.println("Jones123: " + "Jones123".matches(fixed));
    }
}
