import java.util.Arrays;

public class RegexSplit {
    public static void main(String[] args) {
        String s = "Java1HTML2Perl";
        System.out.println("digits: " + Arrays.toString(s.split("\\d")));
        System.out.println("limit 2: " + Arrays.toString(s.split("\\d", 2)));
        String t = "a,b,,";
        String[] a = t.split(",", 0);
        String[] b = t.split(",", -1);
        System.out.println("limit 0: " + Arrays.toString(a));
        System.out.println("length: " + a.length);
        System.out.println("limit -1: " + Arrays.toString(b));
        System.out.println("length: " + b.length);
    }
}
