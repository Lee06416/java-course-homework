// 练习 2.7：把分钟数转换为年数和剩余天数
import java.util.Scanner;

public class MinutesToYearsAndDays {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of minutes: ");
        long minutes = input.nextLong();
        long totalDays = minutes / (24 * 60);
        long years = totalDays / 365;
        long days = totalDays % 365;
        System.out.println(minutes + " minutes is approximately "
                + years + " years and " + days + " days");
    }
}
