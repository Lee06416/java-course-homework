// 练习 2.16：计算正六边形面积
import java.util.Scanner;

public class ComputeHexagonArea {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the length of the side: ");
        double side = input.nextDouble();
        double area = 3 * Math.pow(3, 0.5) / 2 * side * side;
        System.out.println("The area of the hexagon is " + area);
    }
}
