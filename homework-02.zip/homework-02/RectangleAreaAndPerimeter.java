// 练习 1.9：宽 4.5 高 7.9 的矩形的面积和周长
public class RectangleAreaAndPerimeter {
    public static void main(String[] args) {
        System.out.println("Area = " + (4.5 * 7.9));
        System.out.println("Perimeter = " + (2 * (4.5 + 7.9)));
    }
}
