// 练习 2.11：根据输入年数估算人口
import java.util.Scanner;

public class EstimatePopulation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of years: ");
        long years = input.nextLong();
        double seconds = years * 365.0 * 24 * 60 * 60;
        long population = (long) (312032486 + seconds / 7.0
                - seconds / 13.0 + seconds / 45.0);
        System.out.println("The population in " + years + " years is " + population);
    }
}
