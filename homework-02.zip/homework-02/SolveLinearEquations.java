// 练习 1.13：使用 Cramer 法则求解二元一次方程组
public class SolveLinearEquations {
    public static void main(String[] args) {
        System.out.println("x = " + ((44.5 * 0.55 - 50.2 * 5.9)
                / (3.4 * 0.55 - 50.2 * 2.1)));
        System.out.println("y = " + ((3.4 * 5.9 - 44.5 * 2.1)
                / (3.4 * 0.55 - 50.2 * 2.1)));
    }
}
