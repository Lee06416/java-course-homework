// 练习 2.9：计算平均加速度
import java.util.Scanner;

public class ComputeAcceleration {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter v0, v1, and t: ");
        double initialVelocity = input.nextDouble();
        double finalVelocity = input.nextDouble();
        double time = input.nextDouble();
        double acceleration = (finalVelocity - initialVelocity) / time;
        System.out.println("The average acceleration is " + acceleration);
    }
}
