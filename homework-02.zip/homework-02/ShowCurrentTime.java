// 练习 2.8：根据 GMT 时区偏移显示当前时间
import java.util.Scanner;

public class ShowCurrentTime {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the time zone offset to GMT: ");
        double offset = input.nextDouble();
        long totalSeconds = System.currentTimeMillis() / 1000;
        long localSeconds = totalSeconds + Math.round(offset * 3600);
        // 归一化到一天之内，兼容负时区和半小时时区。
        long secondsOfDay = (localSeconds % 86400 + 86400) % 86400;
        long hour = secondsOfDay / 3600;
        long minute = secondsOfDay / 60 % 60;
        long second = secondsOfDay % 60;
        System.out.println("The current time is " + hour + ":" + minute + ":" + second);
    }
}
