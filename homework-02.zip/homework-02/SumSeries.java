// 练习 1.6：计算 1 到 9 的和
public class SumSeries {
    public static void main(String[] args) {
        System.out.println(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9);
    }
}
