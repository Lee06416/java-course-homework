// 练习 1.4：打印平方与立方表格
public class PrintPowerTable {
    public static void main(String[] args) {
        System.out.println("a    a^2    a^3");
        System.out.println("1    1      1");
        System.out.println("2    4      8");
        System.out.println("3    9      27");
        System.out.println("4    16     64");
    }
}
