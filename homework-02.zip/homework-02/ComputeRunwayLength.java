// 练习 2.12：计算飞机起飞所需的最短跑道长度
import java.util.Scanner;

public class ComputeRunwayLength {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter speed and acceleration: ");
        double speed = input.nextDouble();
        double acceleration = input.nextDouble();
        double length = speed * speed / (2 * acceleration);
        System.out.println("The minimum runway length for this airplane is " + length);
    }
}
