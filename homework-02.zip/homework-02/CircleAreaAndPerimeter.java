// 练习 1.8：半径为 5.5 的圆的面积和周长
public class CircleAreaAndPerimeter {
    public static void main(String[] args) {
        System.out.println("Area = " + (5.5 * 5.5 * 3.141592653589793));
        System.out.println("Perimeter = " + (2 * 5.5 * 3.141592653589793));
    }
}
