// 练习 2.13：计算每月存款六个月后的账户金额
import java.util.Scanner;

public class ComputeSavings {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the monthly saving amount: ");
        double monthlySaving = input.nextDouble();
        double monthlyRate = 0.05 / 12;
        // 按题目约定，每月先存款，再计算当月利息。
        double balance = monthlySaving * (1 + monthlyRate);
        balance = (monthlySaving + balance) * (1 + monthlyRate);
        balance = (monthlySaving + balance) * (1 + monthlyRate);
        balance = (monthlySaving + balance) * (1 + monthlyRate);
        balance = (monthlySaving + balance) * (1 + monthlyRate);
        balance = (monthlySaving + balance) * (1 + monthlyRate);
        System.out.println("After the sixth month, the account value is $"
                + Math.round(balance * 100) / 100.0);
    }
}
