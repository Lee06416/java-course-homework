// 练习 2.22：以整数美分输入金额并计算货币单位
import java.util.Scanner;

public class ComputeChange {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter an amount in cents (e.g., 1156 for $11.56): ");
        int amount = input.nextInt();
        int remainingAmount = amount;
        int dollars = remainingAmount / 100;
        remainingAmount %= 100;
        int quarters = remainingAmount / 25;
        remainingAmount %= 25;
        int dimes = remainingAmount / 10;
        remainingAmount %= 10;
        int nickels = remainingAmount / 5;
        int pennies = remainingAmount % 5;
        System.out.println("Your amount of " + amount + " cents consists of");
        System.out.println(dollars + " dollars");
        System.out.println(quarters + " quarters");
        System.out.println(dimes + " dimes");
        System.out.println(nickels + " nickels");
        System.out.println(pennies + " pennies");
    }
}
