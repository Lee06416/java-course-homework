// 练习 1.11：估算未来五年每年的人口
public class PopulationProjection {
    public static void main(String[] args) {
        // 每年按 365 天计算；使用浮点除法，最后转换为整个人数。
        double annualIncrease = 365 * 24 * 60 * 60 / 7.0
                - 365 * 24 * 60 * 60 / 13.0
                + 365 * 24 * 60 * 60 / 45.0;
        System.out.println("Year 1: " + (long) (312032486 + annualIncrease));
        System.out.println("Year 2: " + (long) (312032486 + annualIncrease * 2));
        System.out.println("Year 3: " + (long) (312032486 + annualIncrease * 3));
        System.out.println("Year 4: " + (long) (312032486 + annualIncrease * 4));
        System.out.println("Year 5: " + (long) (312032486 + annualIncrease * 5));
    }
}
