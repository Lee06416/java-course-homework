// 练习 1.10：45 分 30 秒跑 14 千米的平均速度
public class AverageSpeedInMiles {
    public static void main(String[] args) {
        System.out.println("Average speed in miles per hour = "
                + ((14 / 1.6) / ((45 * 60 + 30) / 3600.0)));
    }
}
