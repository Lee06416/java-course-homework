// 练习 2.6：计算 0 到 1000 之间整数的各位数字之和
import java.util.Scanner;

public class SumDigits {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number between 0 and 1000: ");
        int number = input.nextInt();
        int ones = number % 10;
        int tens = number / 10 % 10;
        int hundreds = number / 100 % 10;
        int thousands = number / 1000;
        int sum = ones + tens + hundreds + thousands;
        System.out.println("The sum of the digits is " + sum);
    }
}
