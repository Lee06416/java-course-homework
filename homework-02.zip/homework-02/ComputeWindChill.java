// 练习 2.17：计算风寒温度
import java.util.Scanner;

public class ComputeWindChill {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the temperature in Fahrenheit between -58 and 41: ");
        double temperature = input.nextDouble();
        System.out.print("Enter the wind speed (>= 2) in miles per hour: ");
        double windSpeed = input.nextDouble();
        double windPower = Math.pow(windSpeed, 0.16);
        double windChill = 35.74 + 0.6215 * temperature - 35.75 * windPower
                + 0.4275 * temperature * windPower;
        System.out.println("The wind chill index is " + windChill);
    }
}
