// 练习 1.12：1 小时 40 分 35 秒跑 24 英里的平均速度
public class AverageSpeedInKilometers {
    public static void main(String[] args) {
        System.out.println("Average speed in kilometers per hour = "
                + ((24 * 1.6) / ((3600 + 40 * 60 + 35) / 3600.0)));
    }
}
