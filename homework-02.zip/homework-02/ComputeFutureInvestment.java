// 练习 2.21：计算未来投资金额
import java.util.Scanner;

public class ComputeFutureInvestment {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter investment amount: ");
        double investmentAmount = input.nextDouble();
        System.out.print("Enter annual interest rate in percentage: ");
        double annualInterestRate = input.nextDouble();
        System.out.print("Enter number of years: ");
        int years = input.nextInt();
        double monthlyInterestRate = annualInterestRate / 1200;
        double futureValue = investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12.0);
        System.out.println("Future value is $" + Math.round(futureValue * 100) / 100.0);
    }
}
