// 9.3
import java.util.Date;

public class ShowDates {
    public static void main(String[] args) {
        Date date = new Date();
        for (long time = 10000; time <= 100000000000L; time *= 10) {
            date.setTime(time);
            System.out.println(time + ": " + date.toString());
        }
    }
}
