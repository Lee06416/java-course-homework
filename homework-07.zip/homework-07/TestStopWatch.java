// 9.6：用选择排序处理100000个数
public class TestStopWatch {
    public static void main(String[] args) {
        double[] numbers = new double[100000];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Math.random();
        }

        StopWatch watch = new StopWatch();
        watch.start();
        selectionSort(numbers);
        watch.stop();
        System.out.println("Elapsed time: " + watch.getElapsedTime() + " ms");
    }

    public static void selectionSort(double[] numbers) {
        for (int i = 0; i < numbers.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < numbers.length; j++) {
                if (numbers[j] < numbers[minIndex]) {
                    minIndex = j;
                }
            }
            double temp = numbers[i];
            numbers[i] = numbers[minIndex];
            numbers[minIndex] = temp;
        }
    }
}
