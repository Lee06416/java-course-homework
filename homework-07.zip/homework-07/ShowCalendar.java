// 9.5
import java.util.GregorianCalendar;

public class ShowCalendar {
    public static void main(String[] args) {
        GregorianCalendar calendar = new GregorianCalendar();
        System.out.print("Current date: ");
        printDate(calendar);

        calendar.setTimeInMillis(1234567898765L);
        System.out.print("Specified date: ");
        printDate(calendar);
    }

    public static void printDate(GregorianCalendar calendar) {
        int year = calendar.get(GregorianCalendar.YEAR);
        int month = calendar.get(GregorianCalendar.MONTH) + 1;
        int day = calendar.get(GregorianCalendar.DAY_OF_MONTH);
        System.out.println(year + "-" + month + "-" + day);
    }
}
