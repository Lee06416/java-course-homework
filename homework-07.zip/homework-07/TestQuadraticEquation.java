// 9.10
import java.util.Scanner;

public class TestQuadraticEquation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a, b, c: ");
        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();
        if (a == 0) {
            System.out.println("a must not be 0 for a quadratic equation.");
            return;
        }

        QuadraticEquation equation = new QuadraticEquation(a, b, c);
        double discriminant = equation.getDiscriminant();
        System.out.println("Discriminant: " + discriminant);
        if (discriminant > 0) {
            System.out.println("Roots: " + equation.getRoot1() + " " + equation.getRoot2());
        } else if (discriminant == 0) {
            System.out.println("Root: " + equation.getRoot1());
        } else {
            System.out.println("The equation has no roots.");
        }
    }
}
