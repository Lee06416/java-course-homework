# 第九次作业 多态博客

完整正文见 多态博客.md。运行 PolymorphismDemo.java，实际输出见 运行结果.txt。

```sh
javac -encoding UTF-8 PolymorphismDemo.java
java PolymorphismDemo
```

使用 JDK 11，各次作业请独立编译。
