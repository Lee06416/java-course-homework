public class PolymorphismDemo {
    public static void main(String[] args) {
        Person[] people = {
            new Person("小林"),
            new Student("小李", 2),
            new Teacher("王老师")
        };
        for (Person person : people) {
            printInfo(person);
        }
        Person person = people[1];
        if (person instanceof Student) {
            Student student = (Student) person;
            student.study();
        }
        Person copy = new Person(person);
        System.out.println("复制后：" + copy.getInfo());
    }

    static void printInfo(Person person) {
        System.out.println(person.getInfo());
    }
}

class Person {
    private String name;

    Person(String name) {
        this.name = name;
    }

    Person(Person other) {
        this(other.name);
    }

    String getInfo() {
        return name + "：学校成员";
    }
}

class Student extends Person {
    private int grade;

    Student(String name, int grade) {
        super(name);
        this.grade = grade;
    }

    @Override
    String getInfo() {
        return super.getInfo() + "，学生，年级" + grade;
    }

    void study() {
        System.out.println("学生正在学习 Java");
    }
}

class Teacher extends Person {
    Teacher(String name) {
        super(name);
    }

    @Override
    String getInfo() {
        return super.getInfo() + "，教师";
    }
}
