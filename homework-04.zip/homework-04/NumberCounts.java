// 7.3 计算数字的出现次数
import java.util.Scanner;

public class NumberCounts {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] counts = new int[101];

        System.out.print("Enter the integers between 1 and 100 (0 to end): ");
        int n = input.nextInt();
        while (n != 0) {
            counts[n]++;
            n = input.nextInt();
        }

        for (int i = 1; i <= 100; i++) {
            if (counts[i] == 1) {
                System.out.println(i + " occurs 1 time");
            } else if (counts[i] > 1) {
                System.out.println(i + " occurs " + counts[i] + " times");
            }
        }
    }
}
