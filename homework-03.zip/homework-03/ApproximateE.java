// 5.26 计算 e
public class ApproximateE {
    public static void main(String[] args) {
        double e = 1;
        double item = 1;

        for (int i = 1; i <= 100000; i++) {
            item = item / i;
            e = e + item;

            if (i % 10000 == 0) {
                System.out.println("i = " + i + ", e = " + e);
            }
        }
    }
}
