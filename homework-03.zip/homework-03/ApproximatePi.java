// 5.25 计算圆周率
public class ApproximatePi {
    public static void main(String[] args) {
        double sum = 0;

        for (int i = 1; i <= 100000; i++) {
            if (i % 2 == 1) {
                sum = sum + 1.0 / (2 * i - 1);
            } else {
                sum = sum - 1.0 / (2 * i - 1);
            }

            if (i % 10000 == 0) {
                System.out.println("i = " + i + ", pi = " + 4 * sum);
            }
        }
    }
}
