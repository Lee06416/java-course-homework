// 5.36 检测 ISBN
import java.util.Scanner;

public class ComputeISBN {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the first 9 digits of an ISBN: ");
        int number = input.nextInt();

        int temp = number;
        int sum = 0;

        for (int i = 9; i >= 1; i--) {
            int digit = temp % 10;
            sum = sum + digit * i;
            temp = temp / 10;
        }

        int check = sum % 11;

        System.out.printf("The ISBN-10 number is %09d", number);

        if (check == 10) {
            System.out.println("X");
        } else {
            System.out.println(check);
        }
    }
}
