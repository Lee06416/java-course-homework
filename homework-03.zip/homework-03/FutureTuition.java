// 5.7 计算将来的学费
public class FutureTuition {
    public static void main(String[] args) {
        double tuition = 10000;
        double total = 0;

        for (int i = 1; i <= 10; i++) {
            tuition = tuition * 1.05;
        }

        System.out.printf("Tuition in ten years: %.2f%n", tuition);

        for (int i = 1; i <= 4; i++) {
            total = total + tuition;
            tuition = tuition * 1.05;
        }

        System.out.printf("Total tuition for four years: %.2f%n", total);
    }
}
