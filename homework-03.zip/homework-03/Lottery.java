// 5.32 彩票
import java.util.Scanner;

public class Lottery {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int a = (int) (Math.random() * 10);
        int b = (int) (Math.random() * 10);

        while (a == b) {
            b = (int) (Math.random() * 10);
        }

        int lottery = a * 10 + b;

        System.out.print("Enter your lottery pick (00-99): ");
        int guess = input.nextInt();

        int x = guess / 10;
        int y = guess % 10;

        System.out.println("The lottery number is " + a + b);

        if (guess == lottery) {
            System.out.println("Exact match: you win $10,000");
        } else if (x == b && y == a) {
            System.out.println("Match all digits: you win $3,000");
        } else if (x == a || x == b || y == a || y == b) {
            System.out.println("Match one digit: you win $1,000");
        } else {
            System.out.println("Sorry, no match");
        }
    }
}
