// 5.45 计算平均值和标准方差
import java.util.Scanner;

public class MeanAndDeviation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double sum = 0;
        double squareSum = 0;

        System.out.print("Enter 10 numbers: ");

        for (int i = 1; i <= 10; i++) {
            double number = input.nextDouble();
            sum = sum + number;
            squareSum = squareSum + number * number;
        }

        double mean = sum / 10;
        double variance = (squareSum - sum * sum / 10) / 9;

        // 避免舍入误差产生负数
        if (variance < 0) {
            variance = 0;
        }

        double deviation = Math.sqrt(variance);

        System.out.printf("The mean is %.2f%n", mean);
        System.out.printf("The standard deviation is %.5f%n", deviation);
    }
}
