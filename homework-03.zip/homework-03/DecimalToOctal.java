// 5.38 十进制转换为八进制
import java.util.Scanner;

public class DecimalToOctal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a decimal integer: ");
        int number = input.nextInt();

        long temp = number;
        String result = "";

        if (temp < 0) {
            temp = -temp;
        }

        if (temp == 0) {
            result = "0";
        }

        while (temp > 0) {
            result = temp % 8 + result;
            temp = temp / 8;
        }

        if (number < 0) {
            result = "-" + result;
        }

        System.out.println("The octal value is " + result);
    }
}
