// 5.37 十进制转换为二进制
import java.util.Scanner;

public class DecimalToBinary {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a decimal integer: ");
        int number = input.nextInt();

        long temp = number;
        String result = "";

        if (temp < 0) {
            temp = -temp;
        }

        if (temp == 0) {
            result = "0";
        }

        while (temp > 0) {
            result = temp % 2 + result;
            temp = temp / 2;
        }

        if (number < 0) {
            result = "-" + result;
        }

        System.out.println("The binary value is " + result);
    }
}
