// 5.21 比较不同利率下的贷款
import java.util.Scanner;

public class CompareLoanRates {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Loan amount: ");
        double loan = input.nextDouble();

        System.out.print("Number of years: ");
        int years = input.nextInt();

        System.out.println("Interest Rate   Monthly Payment   Total Payment");

        for (double rate = 5; rate <= 8; rate = rate + 0.125) {
            double monthlyRate = rate / 1200;
            double payment = loan * monthlyRate
                    / (1 - 1 / Math.pow(1 + monthlyRate, years * 12));
            double total = payment * years * 12;

            System.out.printf("%6.3f%%         %10.2f        %10.2f%n",
                    rate, payment, total);
        }
    }
}
