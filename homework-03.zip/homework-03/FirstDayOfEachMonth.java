// 5.28 显示每月第一天是星期几
import java.util.Scanner;

public class FirstDayOfEachMonth {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter year: ");
        int year = input.nextInt();

        System.out.print("Enter the first weekday (0-6): ");
        int week = input.nextInt();

        for (int month = 1; month <= 12; month++) {
            String name = "";
            int days = 31;

            switch (month) {
                case 1: name = "January"; break;
                case 2: name = "February"; break;
                case 3: name = "March"; break;
                case 4: name = "April"; break;
                case 5: name = "May"; break;
                case 6: name = "June"; break;
                case 7: name = "July"; break;
                case 8: name = "August"; break;
                case 9: name = "September"; break;
                case 10: name = "October"; break;
                case 11: name = "November"; break;
                case 12: name = "December"; break;
            }

            if (month == 4 || month == 6 || month == 9 || month == 11) {
                days = 30;
            } else if (month == 2) {
                if (year % 400 == 0
                        || (year % 4 == 0 && year % 100 != 0)) {
                    days = 29;
                } else {
                    days = 28;
                }
            }

            String weekName = "";

            switch (week) {
                case 0: weekName = "Sunday"; break;
                case 1: weekName = "Monday"; break;
                case 2: weekName = "Tuesday"; break;
                case 3: weekName = "Wednesday"; break;
                case 4: weekName = "Thursday"; break;
                case 5: weekName = "Friday"; break;
                case 6: weekName = "Saturday"; break;
            }

            System.out.println(name + " 1, " + year + " is " + weekName);

            week = (week + days) % 7;
        }
    }
}
