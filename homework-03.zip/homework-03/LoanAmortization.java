// 5.22 显示分期还贷时间表
import java.util.Scanner;

public class LoanAmortization {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Loan amount: ");
        double loan = input.nextDouble();

        System.out.print("Number of years: ");
        int years = input.nextInt();

        System.out.print("Annual interest rate: ");
        double rate = input.nextDouble();

        int months = years * 12;
        double monthlyRate = rate / 1200;
        double payment;

        if (rate == 0) {
            payment = loan / months;
        } else {
            payment = loan * monthlyRate
                    / (1 - 1 / Math.pow(1 + monthlyRate, months));
        }

        System.out.printf("Monthly payment: %.2f%n", payment);
        System.out.printf("Total payment: %.2f%n", payment * months);
        System.out.println("Payment#     Interest     Principal     Balance");

        double balance = loan;

        for (int i = 1; i <= months; i++) {
            double interest = balance * monthlyRate;
            double principal = payment - interest;

            // 最后一期还清余额
            if (i == months) {
                principal = balance;
            }

            balance = balance - principal;

            System.out.printf("%-12d%-13.2f%-14.2f%.2f%n",
                    i, interest, principal, balance);
        }
    }
}
