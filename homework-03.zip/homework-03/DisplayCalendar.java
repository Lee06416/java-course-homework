// 5.29 显示日历
import java.util.Scanner;

public class DisplayCalendar {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter year: ");
        int year = input.nextInt();

        System.out.print("Enter the first weekday (0-6): ");
        int week = input.nextInt();

        for (int month = 1; month <= 12; month++) {
            String name = "";
            int days = 31;

            switch (month) {
                case 1: name = "January"; break;
                case 2: name = "February"; break;
                case 3: name = "March"; break;
                case 4: name = "April"; break;
                case 5: name = "May"; break;
                case 6: name = "June"; break;
                case 7: name = "July"; break;
                case 8: name = "August"; break;
                case 9: name = "September"; break;
                case 10: name = "October"; break;
                case 11: name = "November"; break;
                case 12: name = "December"; break;
            }

            if (month == 4 || month == 6 || month == 9 || month == 11) {
                days = 30;
            } else if (month == 2) {
                if (year % 400 == 0
                        || (year % 4 == 0 && year % 100 != 0)) {
                    days = 29;
                } else {
                    days = 28;
                }
            }

            System.out.println();
            System.out.println("        " + name + " " + year);
            System.out.println("----------------------------");
            System.out.println(" Sun Mon Tue Wed Thu Fri Sat");

            for (int i = 0; i < week; i++) {
                System.out.print("    ");
            }

            for (int day = 1; day <= days; day++) {
                System.out.printf("%4d", day);

                if ((week + day) % 7 == 0) {
                    System.out.println();
                }
            }

            if ((week + days) % 7 != 0) {
                System.out.println();
            }

            week = (week + days) % 7;
        }
    }
}
